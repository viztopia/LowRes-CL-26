STORAGE

Everything here was once "important."

There are several numbered boxes.

Someone wrote on the wall:

"Apparently one of these boxes matters.
Good luck."
