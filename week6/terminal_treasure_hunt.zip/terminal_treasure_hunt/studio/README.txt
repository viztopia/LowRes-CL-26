STUDIO

Current contents:

- unfinished projects
- cables
- suspiciously many adapters
- one desk
- one supply closet

A note on the wall says:

"The first fragment is somewhere
people leave things they were using five minutes ago."
