SERVER ROOM
===========

The machine is here.
It is powered off.

Someone taped a note to the rack:

"The next useful thing is attached somewhere on the rack,
not buried in the logs."
