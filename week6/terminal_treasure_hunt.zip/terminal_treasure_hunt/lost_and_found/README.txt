LOST & FOUND

Found this week:

- chargers
- umbrellas
- water bottles
- jackets
- bags
- one lonely AirPod

Things get sorted roughly by type.

If you're looking for something personal,
you may need to open a few folders.
