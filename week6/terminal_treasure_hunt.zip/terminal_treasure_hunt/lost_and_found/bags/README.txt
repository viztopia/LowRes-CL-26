BAGS

Two bags were left behind:

- backpack
- tote_bag

One contains school supplies.
One contains mostly chaos.
